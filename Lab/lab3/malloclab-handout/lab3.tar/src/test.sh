echo "./mdriver -v -f ./traces/amptjp-bal.rep" &&
./mdriver -v -f ./traces/amptjp-bal.rep &&
echo "./mdriver -v -f ./traces/amptjp.rep" &&
./mdriver -v -f ./traces/amptjp.rep &&
echo "./mdriver -v -f ./traces/binary-bal.rep" &&
./mdriver -v -f ./traces/binary-bal.rep &&
echo "./mdriver -v -f ./traces/binary.rep" &&
./mdriver -v -f ./traces/binary.rep &&
echo "./mdriver -v -f ./traces/cccp-bal.rep" &&
./mdriver -v -f ./traces/cccp-bal.rep &&
echo "./mdriver -v -f ./traces/cccp.rep" &&
./mdriver -v -f ./traces/cccp.rep &&
echo "./mdriver -v -f ./traces/coalescing-bal.rep" &&
./mdriver -v -f ./traces/coalescing-bal.rep &&
echo "./mdriver -v -f ./traces/coalescing.rep" &&
./mdriver -v -f ./traces/coalescing.rep &&
echo "./mdriver -v -f ./traces/cp-decl-bal.rep" &&
./mdriver -v -f ./traces/cp-decl-bal.rep &&
echo "./mdriver -v -f ./traces/cp-decl.rep" &&
./mdriver -v -f ./traces/cp-decl.rep &&
echo "./mdriver -v -f ./traces/expr-bal.rep" &&
./mdriver -v -f ./traces/expr-bal.rep &&
echo "./mdriver -v -f ./traces/expr.rep" &&
./mdriver -v -f ./traces/expr.rep &&
echo "./mdriver -v -f ./traces/random-bal.rep" &&
./mdriver -v -f ./traces/random-bal.rep &&
echo "./mdriver -v -f ./traces/random.rep" &&
./mdriver -v -f ./traces/random.rep &&
echo "./mdriver -v -f ./traces/random2-bal.rep" &&
./mdriver -v -f ./traces/random2-bal.rep &&
echo "./mdriver -v -f ./traces/random2.rep" &&
./mdriver -v -f ./traces/random2.rep &&
echo "./mdriver -v -f ./traces/realloc-bal.rep" &&
./mdriver -v -f ./traces/realloc-bal.rep &&
echo "./mdriver -v -f ./traces/realloc.rep" &&
./mdriver -v -f ./traces/realloc.rep &&
echo "./mdriver -v -f ./traces/realloc2-bal.rep" &&
./mdriver -v -f ./traces/realloc2-bal.rep &&
echo "./mdriver -v -f ./traces/realloc2.rep" &&
./mdriver -v -f ./traces/realloc2.rep &&
echo "./mdriver -v -f ./traces/short1-bal.rep" &&
./mdriver -v -f ./traces/short1-bal.rep &&
echo "./mdriver -v -f ./traces/short1.rep" &&
./mdriver -v -f ./traces/short1.rep &&
echo "./mdriver -v -f ./traces/short2-bal.rep" &&
./mdriver -v -f ./traces/short2-bal.rep &&
echo "./mdriver -v -f ./traces/short2.rep" &&
./mdriver -v -f ./traces/short2.rep